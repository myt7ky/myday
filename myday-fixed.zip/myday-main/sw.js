const CACHE='myday-pwa-v32';
const CORE=['./','./index.html','./app/app.html?v=32','./manifest.webmanifest','./icon.svg'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(CORE).catch(()=>{})).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==CACHE).map(x=>caches.delete(x)))).then(()=>self.clients.claim())));
/* сеть в приоритете (всегда свежая версия), при отсутствии сети — кэш */
self.addEventListener('fetch',e=>{
  const r=e.request;if(r.method!=='GET')return;const u=new URL(r.url);if(u.origin!==self.location.origin||u.pathname.startsWith('/api/'))return;
  e.respondWith(fetch(r).then(res=>{if(res.ok){const c=res.clone();caches.open(CACHE).then(k=>k.put(r,c))}return res}).catch(()=>caches.match(r,{ignoreSearch:false}).then(x=>x||caches.match(r,{ignoreSearch:true})).then(x=>x||caches.match('./index.html'))))});
